# Python Assignment

Python practice questions and a simple Mobile Shop CRUD project.

## Contents
- `python-questions/` — Questions 1-30
- `mobile-shop-crud/` — Mobile Shop CRUD project

## Run
```bash
python python-questions/01_even_odd.py
python mobile-shop-crud/mobile_shop.py
```
